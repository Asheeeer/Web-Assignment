// document.addEventListener('DOMContentLoaded', () => {
//   const messagesContainer = document.getElementById('messages');
//   const inputMessage = document.getElementById('input-message');
//   const sendButton = document.getElementById('send-button');

//   const username = prompt('Enter your name'); // 提示用户输入名字
//   if (username.trim() !== '') {
//     const message = `${username} joined the chat room`; // 创建加入通知消息
//     const messageElement = document.createElement('div');
//     messageElement.textContent = message;
//     messagesContainer.appendChild(messageElement);
//   }

//   sendButton.addEventListener('click', () => {
//     const message = inputMessage.value;
//     if (message.trim() !== '') {
//       const messageElement = document.createElement('div');
//       messageElement.textContent = message;
//       messagesContainer.appendChild(messageElement);
//       inputMessage.value = '';
//     }
//   });
// });

// document.addEventListener('DOMContentLoaded', () => {
//   const messagesContainer = document.getElementById('messages');
//   const inputMessage = document.getElementById('input-message');
//   const sendButton = document.getElementById('send-button');

//   const socket = io();

//   // 用户加入聊天室
//   const username = prompt('Enter your name');
//   if (username.trim() !== '') {
//     socket.emit('join', username);
//   }

//   // 接收消息
//   socket.on('message', (message) => {
//     const messageElement = document.createElement('div');
//     messageElement.textContent = message;
//     messagesContainer.appendChild(messageElement);
  
//  // 检查是否是加入通知消息
//   if (message.includes('joined the chat room')) {
//     // 显示通知消息在原先的用户窗口中
//     const notificationElement = document.createElement('div');
//     notificationElement.textContent = message;
//     document.body.appendChild(notificationElement);
//   }
  
//   });

//   // 发送消息
//   sendButton.addEventListener('click', () => {
//     const message = inputMessage.value;
//     if (message.trim() !== '') {
//       socket.emit('message', message);
//       inputMessage.value = '';
//     }
//   });
// });
// 保命代码，不要删除


// document.addEventListener('DOMContentLoaded', () => {
//   const messagesContainer = document.getElementById('messages');
//   const inputMessage = document.getElementById('input-message');
//   const sendButton = document.getElementById('send-button');

//   const socket = io({
//   path: '/socket.io',
//   transports: ['websocket'],
//   });



  
//   // 用户加入聊天室
//   const username = prompt('Enter your name');
//   if (username.trim() !== '') {
//     const message = `${username} joined the chat room`; // 创建加入通知消息
//     const messageElement = document.createElement('div');
//     messageElement.textContent = message;
//     messagesContainer.appendChild(messageElement);

//     socket.emit('join', username);
//   }

//   // 接收消息
//   socket.on('message', (message) => {
//     const messageElement = document.createElement('div');
//     messageElement.textContent = message;
//     messagesContainer.appendChild(messageElement);

//     // 检查是否是加入通知消息
//     if (message.includes('joined the chat room')) {
//       // 显示通知消息在原先的用户窗口中
//       const notificationElement = document.createElement('div');
//       notificationElement.textContent = message;
//       document.body.appendChild(notificationElement);
//     }
//   });

//   // 发送消息
//   sendButton.addEventListener('click', () => {
//     const message = inputMessage.value;
//     if (message.trim() !== '') {
//       socket.emit('message', message);
//       inputMessage.value = '';
//     }
//   });
// });


//目前有错误的代码

document.addEventListener('DOMContentLoaded', () => {
  const messagesContainer = document.getElementById('messages');
  const inputMessage = document.getElementById('input-message');
  const sendButton = document.getElementById('send-button');

  const username = prompt('Enter your name'); // 提示用户输入名字
  if (username.trim() !== '') {
    const message = `${username} joined the chat room`; // 创建加入通知消息
    const messageElement = document.createElement('div');
    messageElement.textContent = message;
    messagesContainer.appendChild(messageElement);
  }

  sendButton.addEventListener('click', () => {
    const message = inputMessage.value;
    if (message.trim() !== '') {
      const messageElement = document.createElement('div');
      messageElement.textContent = message;
      messagesContainer.appendChild(messageElement);
      inputMessage.value = '';
    }
  });
});
