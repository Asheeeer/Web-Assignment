const http = require('http');
const fs = require('fs');
const io = require('socket.io')(server);

const server = http.createServer((req, res) => {
  // 处理 HTTP 请求
  if (req.method === 'GET' && req.url === '/') {
    // 如果请求路径是根目录，读取 ChatAPP.html 并返回
    fs.readFile('ChatAPP.html', (err, data) => {
      if (err) {
        // 如果读取出错，返回 500 状态码
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
      } else {
        // 返回 HTML 内容
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
      }
    });
  } else {
    // 如果请求路径不是根目录，返回 404 状态码
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
});

// 启动服务器
const PORT = process.env.PORT || 8000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
//保命代码，不要删除

// const http = require('http');
// const fs = require('fs');
// const socketio = require('socket.io');

// const server = http.createServer((req, res) => {
//   // 处理 HTTP 请求
//   if (req.method === 'GET' && req.url === '/') {
//     // 如果请求路径是根目录，读取 ChatAPP.html 并返回
//     fs.readFile('ChatAPP.html', (err, data) => {
//       if (err) {
//         // 如果读取出错，返回 500 状态码
//         res.writeHead(500, { 'Content-Type': 'text/plain' });
//         res.end('Internal Server Error');
//       } else {
//         // 返回 HTML 内容
//         res.writeHead(200, { 'Content-Type': 'text/html' });
//         res.end(data);
//       }
//     });
//   } else if (req.method === 'GET' && req.url === '/socket.io/socket.io.js') {
//     // 处理 Socket.IO 客户端库请求
//     // 读取 Socket.IO 客户端库文件并返回
//     fs.readFile('node_modules/socket.io/client-dist/socket.io.js', (err, data) => {
//       if (err) {
//         // 如果读取出错，返回 500 状态码
//         res.writeHead(500, { 'Content-Type': 'text/plain' });
//         res.end('Internal Server Error');
//       } else {
//         // 返回 Socket.IO 客户端库内容
//         res.writeHead(200, { 'Content-Type': 'application/javascript' });
//         res.end(data);
//       }
//     });
//   } else {
//     // 如果请求路径不是根目录或 Socket.IO 客户端库路径，返回 404 状态码
//     res.writeHead(404, { 'Content-Type': 'text/plain' });
//     res.end('Not Found');
//   }
// });

// // 创建 WebSocket 服务器
// const io = socketio(server, {
//   path: '/socket.io',
//   serveClient: true, // 启用客户端文件服务
// });

// // 用户连接处理逻辑
// io.on('connection', (socket) => {
//   // 用户加入聊天室
//   socket.on('join', (username) => {
//     socket.broadcast.emit('message', `${username} joined the chat room`);
//   });

//   // 接收消息
//   socket.on('message', (message) => {
//     io.emit('message', message);
//   });

//   // 用户断开连接
//   socket.on('disconnect', () => {
//     socket.broadcast.emit('message', 'A user left the chat room');
//   });
// });

// // 启动服务器
// const PORT = process.env.PORT || 8000;
// server.listen(PORT, () => {
//   console.log(`Server listening on port ${PORT}`);
// });
