// const express = require('express');
// const bodyParser = require('body-parser')

// const app = express();
// const chat = require('./chat.js');

// // 在这里使用 chat.js 中的功能
 
// app.use( bodyParser.json() );       // to support JSON-encoded bodies
// app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
//   extended: true
// })); 

// app.use(express.static('public'))


// // index page
// app.get('/testGet', function(req, res) {	
//   let firstName = req.query.firstName
//   let surname = req.query.surname
  
//   res.send(`
//            <!doctype html>
//            <head>
//            <title>Test GET</title> 
//            </head>
//            <body>
// <strong> First Name:</strong>${firstName} <br>
// <strong> Surname:</strong>${surname}
//            </body> 
//            `);
// });


// app.post('/testPost', function(req, res) {
// 	let firstName = req.body.firstName
//     let surname = req.body.surname

// res.send(`
//            <!doctype html>
//            <head>
//            <title>Test POST</title> 
//            </head>
//            <body>
// <strong> First Name:</strong>${firstName} <br>
// <strong> Surname:</strong>${surname}
//            </body> 
//            `)
  
// });


// app.get('/test404', function(req, res) {
    
//     res.status(404);
//     res.send ('Not Found')
// });

// app.get('/test403', function(req, res) {
//      res.status(403);
//     res.send ('Forbidden')
// });

// app.get('/test500', function(req, res) {
//     //something that breaks
//     let b = z
    
// });

// app.post('/practical5', function(req, res) {
// 	let name = req.body.firstName
//     let email = req.body.surname
//     let gender = req.body.gender
//     let genre = req.body.genre
//     let username = req.body.username
//     let message = req.body.message

// res.send(`
//            <!doctype html>
//            <head>
//            <title>Test POST</title> 
//            </head>
//            <body>
// <strong> Name:</strong>${name} <br>
// <strong> Email:</strong>${email}<br>
// <strong> Gender:</strong>${gender}<br>
// <strong> Genre:</strong>${genre}<br>
// <strong> Message:</strong>${message}<br>
// <strong> User Name:</strong>${username}
//            </body> 
//            `)
  
// });


// app.listen(8080);
// console.log('Server is listening on port 8080');


const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
  // 处理 HTTP 请求
  if (req.method === 'GET' && req.url === '/') {
    // 如果请求路径是根目录，读取 ChatAPP.html 并返回
    fs.readFile('ChatAPP.html', (err, data) => {
      if (err) {
        // 如果读取出错，返回 500 状态码
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
      } else {
        // 返回 HTML 内容
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
      }
    });
  } else {
    // 如果请求路径不是根目录，返回 404 状态码
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
});

// 启动服务器
const PORT = process.env.PORT || 8000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
