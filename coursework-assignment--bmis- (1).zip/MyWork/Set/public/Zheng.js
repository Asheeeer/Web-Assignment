const socket = io();
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const chatMessages = document.getElementById('chat-messages');

// Listen for chat messages
socket.on('message', message => {
    outputMessage(message);
    chatMessages.scrollTop = chatMessages.scrollHeight;
});

// Submit message
chatForm.addEventListener('submit', e => {
    e.preventDefault();
    const msg = chatInput.value;
    socket.emit('chatMessage', msg);
    chatInput.value = '';
});

// Output message to DOM
function outputMessage(message) {
    const div = document.createElement('div');
    div.classList.add('message');
    div.innerHTML = `<p><strong>${message.username}</strong> ${message.time}</p><p>${message.text}</p>`;
    chatMessages.appendChild(div);
}
